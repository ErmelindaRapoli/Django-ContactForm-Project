#!c:\users\ermelinda.rapoli\work\corsi\python\10_django_lv_3\contact_env\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
