from django.db import models

# Create your models here.
class ContactModel(models.Model):
    nome = models.CharField(max_length=100)
    email = models.EmailField()
    oggetto = models.CharField(max_length=100)
    contenuto = models.TextField()

    class Meta:
        verbose_name = "Contatto"
        verbose_name_plural = "Contatti"

    def __str__(self):
        return self.email
