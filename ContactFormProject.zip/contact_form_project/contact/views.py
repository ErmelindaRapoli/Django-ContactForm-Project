from django.shortcuts import render, HttpResponseRedirect
from .forms import ContactModelForm

# Create your views here.
def homepage(request):
    return render(request, "homepage.html")

def contactView(request):
    if request.method == "POST":
        form = ContactModelForm(request.POST)
        if form.is_valid():
            print("Il form è valido")
            new_contact_form = form.save()
            print("new_contact_form", new_contact_form)
            return HttpResponseRedirect("/thankyou")
    else:
        form = ContactModelForm()

    context = {"form": form}
    return render(request, "contatti.html", context)

def thankView(request):
    return render(request, "thankyou.html")
